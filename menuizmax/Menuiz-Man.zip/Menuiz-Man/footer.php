
<footer>
    <img class="logo footLogo" src="img\MenuizMan_logo.png" alt="logo">
    <p class="mention">Mentions légales</p>
    <p class="copy">Copyright © Maxime Bizeau</p>
    <p class="mail">Mail : support@exemple.com</p>
</footer>